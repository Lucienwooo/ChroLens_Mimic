opencv_version = "4.12.0.88"
contrib = False
headless = True
rolling = False
ci_build = True